import { Component } from '@angular/core';

@Component({
  selector: 'app-layout-blank',
  templateUrl: './layout-blank.component.html',
  styles: [':host { display: block; }']
})
export class LayoutBlankComponent {}
